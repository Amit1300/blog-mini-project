import React from 'react'
import { Switch } from 'react-router'

function Reducer (state = {}, action) {
  switch (action.type) {
    case 'DATA':
      return {
        ...state,
        blogs: action.payload
      }

    case 'DEL':
      console.log(state)
      return {
        ...state,
        blogs: state.blogs.filter(item => item.id !== action.payload)
      }
    case 'update':
      return {
        ...state,
        blogs: [...state.blogs, action.payload]
      }

    default:
      return state
  }
}

export default Reducer
