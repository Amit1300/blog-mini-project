import React, { Component } from 'react'
import { Button, Jumbotron } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import './start.css'
export default class Starter extends Component {
  constructor(props){
    super(props)
  }




  
  render () {
   
    return (
      <div  className="container" id="anime">
        <Jumbotron className="m-5 text-center  rounded-circle  " id="jumb">
          <h1>Hello, world!</h1>
          <p>
            This is Amit Nagar trying to make his project of blog app to get a
            concept how react.js and django works.
          </p>
          <p>
            <Button variant='primary m-5' id='button'>
              <Link style={{textDecoration:"none",color:"white"}} to='/login'>LOGIN IN</Link>
            </Button>
            <Button  variant='primary' id="button">
              <Link style={{textDecoration:"none",color:"white"}}  to='/signup'>SIGN UP</Link>
            </Button>
          </p>
        </Jumbotron>
      </div>
    )
  }
}
