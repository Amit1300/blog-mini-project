import React, { Component } from 'react'
// import 'bootstrap/dist/css/bootstrap.css';
import { Link,useHistory } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css'
import { withCookies, Cookies } from 'react-cookie';
import {connect} from 'react-redux'
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import {
  Navbar,
  Form,
  FormControl,
  Nav,
  NavDropdown,
  Card,
  CardImg
} from 'react-bootstrap'


export default class Author extends Component {
  constructor (props) {
    super(props)
    this.state = {
      author:[],
    }
  }

  logout=()=>{
    localStorage.clear()
     this.props.history.replace('/Login')
  }

  handledelete=(id)=>{
   
   
    let token=localStorage.getItem('token')
    
      fetch(`http://127.0.0.1:8000/blog/${id}/`, {
        method: 'DELETE',
        headers: {
          'Content-type': 'application/json',
          'Authorization':`Token ${token}`
        }
      }).then(res=>{
        console.log(res)
        this.props.del(id)
        
        
      }).catch(err=>console.log(err))
  }

  componentDidMount () {
    let token=localStorage.getItem('token')
    
    let url = `http://127.0.0.1:8000/api/blog`
    fetch(url, {
      method: 'GET',
      headers: {
        'Content-type': 'multipart/form-data',
        'Authorization':`Token ${token}`
      }
    })
      .then(response => response.json())
      .then(data => {
          console.log(data)
        this.setState({ author: data })})
      .catch(error => console.log(error))
  }
  render () {
    // console.log(this.props.blogs)
   
    console.log(this.state.author)
    return (
      <div>
         <h1 style={{textAlign:'center'}}>Authors</h1>
           {this.state.author.length!=0 ?
       ( <div className='container-fluid m-3' >
          <div className='row'>
            {this.state.author.map(item => (
              <div className='col-lg-4 '>
                <Card key={item.id} className='card' style={{ width: '28rem' }} id="card">
                  <Card.Body id='car'>
                    <Card.Title className='primary-text'  style={{textAlign:'center'}}>
                      {/* {item.title}
                      {item.blog} */}
                    <h4>{item.Author}</h4>
                    </Card.Title>
                    {/* <Card.Text>{item.content}...</Card.Text> */}
{/* 
                    <Button
                      onClick={() => {
                        this.handledelete(item.id)
                      }}
                    > */}
             
                    {/* </Button>
                    <IconButton aria-label='delete' id="icon">
                      <DeleteIcon
                        onClick={() => {
                          this.handledelete(item.id)
                        }}
                        variant='outlined'
                        color='secondary'
                      />
                    </IconButton>
                    <Button id="but">
                      <Link
                        style={{ textDecoration: 'none' }}
                        to={`/edit/${item.id}`}
                      >
                        Edit
                      </Link>
                    </Button> */}
                  </Card.Body>
                </Card>
              </div>
            ))}
          </div>
        </div>):<h1>no blog</h1>}
       
    
        </div>
     
    )
  }
}
