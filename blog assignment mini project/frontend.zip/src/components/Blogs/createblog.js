import React, { Component } from 'react'
import axios from 'axios'
import './create_page.css'
export default class CreateBlog extends Component {
  constructor (props) {
    super(props)
    this.state = {
      //   thumbnail:null,
      title: '',
      category: '',
      content: '',
      date_created: '',
      Author: '',
      blog:"",
    }
  }

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value })
  }

  handleChangeImage = e => {
    this.setState({ thumbnail: e.target.value })
  }

  handleSubmit = e => {
    const user = localStorage.getItem('access')
    let url = `http://127.0.0.1:8000/blog`
    e.preventDefault()

    // let form_data = new FormData();
    // form_data.append('thumbnail', this.state.thumbnail)
    // form_data.append('title', this.state.title);
    // form_data.append('content', this.state.content);
    // form_data.append('date_created', this.state.date_created);
    // form_data.append('blog',this.state.blog)
    // form_data.append('category',this.state.category)
    // form_data.append('author',this.state.author)
    // console.log(form_data)
    let token = localStorage.getItem('token')

    fetch('http://127.0.0.1:8000/api/blog', {
      method: 'POST',
      body: JSON.stringify(this.state),
      headers: {
        'content-type': 'application/json',
        //  'Content-Type': 'multipart/form-data',

        Authorization: `Token ${token}`
      }
    })
      .then(res => res.json())
      .then(data => console.log(data))
  }
  cat = e => {
    this.setState({ category: e.target.value })
  }

  render () {
    return (
      <div className='container'  >
        <form onSubmit={this.handleSubmit} id="main">
          <label>author</label>
          <input
            type='text'
            name='Author'
            value={this.state.Author}
            onChange={this.handleChange}
          />
          <label>Blog</label>
          <input
            type='text'
            name='blog'
            value={this.state.blog}
            onChange={this.handleChange}
          />
          <label>title</label>
          <input
            type='text'
            name='title'
            value={this.state.title}
            onChange={this.handleChange}
          />
          {/* <label>thumbnail</label>
            <input type="file" name="thumbnail" accept="image/png, image/jpeg" value={this.state.thumbnail} onChange={this.handleChangeImage} /> */}
          <label>date</label>
          <input
            type='date'
            name='date_created'
            value={this.state.date_created}
            onChange={this.handleChange}
          />
          <label>content</label>
          <textarea
            name='content'
            value={this.state.content}
            onChange={this.handleChange}
          >
            {' '}
          </textarea>
          <label>category</label>
          <select onChange={this.cat} id='cat' value={this.state.category}>
            <option value='world'>world</option>
            <option value='world'>world</option>
          </select>
          <input type='submit' value='submit' id='in' />
        </form>
      </div>
    )
  }
}
