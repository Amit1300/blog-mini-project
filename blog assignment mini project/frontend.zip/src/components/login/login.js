import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.css'
import { useHistory } from 'react-router-dom'
import { useCookies } from 'react-cookie'
import './login_page.css'
function Login () {
  const [data, setdata] = useState([])
  const [username, setusername] = useState('')
  const [password, setpassword] = useState('')
  // const[token,settoken]=useCookies(['mytoken'])

  let history = useHistory()

  const click = e => {
    e.preventDefault()
    let username = e.target['username'].value
    let password = e.target['password'].value
    fetch('http://127.0.0.1:8000/api-token-auth/', {
      method: 'POST',
      body: JSON.stringify({
        username: username,
        password: password
      }),
      headers: {
        'Content-type': 'application/json'
      }
    })
      .then(response => response.json())
      .then(response => {
        console.log(response.token)
        localStorage.setItem('token', response.token)
        if (response.token) {
          history.push('/home')
        }
      })
      .catch(err => console.log(err))
  }

  // useEffect(()=>{
  //   if(token['mytoken']){
  //     history.push("/home")
  //   }
  // })

  const onchange = e => {
    setusername(e.target.value)
  }

  const onchangePass = e => {
    setpassword(e.target.value)
  }
  return (
    <div className='container ' id='login'>
      <div
        className='row text-center m-5 text-center'
      >
        <div className="col-6">
        <form onSubmit={click} id='form' className='text-sucess '>
          <label>UserName</label>
          <input
            type='text'
            value={username}
            name='username'
            onChange={onchange}
          />
          <label>Password</label>
          <input
            type='password'
            value={password}
            name='password'
            onChange={onchangePass}
          />
          <button type='submit'  id='button'>
            Sign in{' '}
          </button>
        </form>
        </div>
      </div>
    </div>
  )
}

export default Login
