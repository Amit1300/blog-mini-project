import './signup.css'
import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.css'
function SignUp () {
  const [data, setdata] = useState([])
  const [username, setusername] = useState('')
  const [password, setpassword] = useState('')
  const [email, setemail] = useState('')

  const click = e => {
    e.preventDefault()
    let username = e.target['username'].value
    let password = e.target['password'].value
    let email = e.target['email'].value
    let form_data = new FormData()
    form_data.append('username', username)
    form_data.append('password', password)
    form_data.append('email', email)
    fetch('http://127.0.0.1:8000/api/signup/', {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        username: username,
        password: password,
        email: email
      })
    })
      .then(response => response.json())
      .then(response => console.log(response))
  }

  const onchange = e => {
    setusername(e.target.value)
  }

  const onchangePass = e => {
    setpassword(e.target.value)
    setemail(e.target.value)
  }
  const onchangeEmail = e => {
    setemail(e.target.value)
  }
  return (
    <div className='container'>
      <div
        style={{ marginLeft: '400px', marginTop: '200px' }}
        className='row col-6'
      >
        <form onSubmit={click } id='form'>
          <label>UserName</label>
          <input
            type='text'
            value={username}
            name='username'
            onChange={onchange}
          />
          <label>Password</label>
          <input
            type='password'
            value={password}
            name='password'
            onChange={onchangePass}
          />
          <label>email</label>
          <input
            type='Email'
            value={email}
            name='email'
            onChange={onchangeEmail}
          />
          <button type='submit' className='button' id='button'>
            Sign up{' '}
          </button>
        </form>
      </div>
    </div>
  )
}

export default SignUp
