import React, { Component } from 'react'
import axios from 'axios'
import {connect} from 'react-redux'

 export default class Editdetails extends Component {
  constructor (props) {
    super(props)
    this.state = {
      author:this.props.item.author,
      blog:this.props.item.blog,
      title:this.props.item.title,
      category:this.props.item.category,
      content:this.props.item.content,
      date_created:this.props.item.date_created
    }
  
}

     



handleChange=(e)=>{
    this.setState({[e.target.name]:e.target.value})
}

  render() {
   
    return (
      <div id='main'>
        <label>author</label>
       
       <input type="text" name="author"  value={this.state.author} onChange={this.handleChange} />
         <label>Blog</label>
       
            <input type="text" name="blog"  value={this.state.blog} onChange={this.handleChange} />
            <label>title</label>
            <input type="text" name="title"  value={this.state.title} onChange={this.handleChange} />
            {/* <label>thumbnail</label>
            <input type="file" name="thumbnail" accept="image/png, image/jpeg" value={this.state.thumbnail} onChange={this.handleChangeImage} /> */}
            <label>date</label>
            <input type="date" name="date_created"  value={this.state.date_created} onChange={this.handleChange} />
            <label>content</label>
            <input type="text" name="content"  value={this.state.content} onChange={this.handleChange} />
            <label>category</label>
            <select onChange={this.cat}  id="cat" value={this.state.category}>
                <option value="world">world</option>
                <option value="world">world</option>
                <option value="world">world</option>
                <option value="world">world</option>
            </select>
            <input type="submit" onClick={()=>{this.props.handleSubmit(this.state)}} value='submit'/>
    
            
       
     
      </div>
    )
  }
}