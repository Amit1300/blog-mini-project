import React, { Component } from 'react'
import axios from 'axios'
import { connect } from 'react-redux'
import Editdetails from './editedetails'
import './edit.css'
class Edit extends Component {
  constructor (props) {
    super(props)
    this.state = {
      blog: '',
      title: '',
      category: '',
      content: '',
      date_created: ''
    }
  }

  handleSubmit = data => {
    const { id } = this.props.match.params

    // let form_data = new FormData();
    // form_data.append('title', data.title);
    // form_data.append('content', data.content);
    // form_data.append('date_created', data.date_created);
    // form_data.append('blog',data.blog)
    // form_data.append('category',data.category)
    // console.log(form_data)
    let token = localStorage.getItem('token')

    fetch(`http://127.0.0.1:8000/api/blog/${id}/`, {
      method: 'PUT',
      body: JSON.stringify(data),
      headers: {
        'content-type': 'application/json',
        //  'Content-Type': 'multipart/form-data',

        Authorization: `Token ${token}`
      }
    })
      .then(res => res.json())
      .then(data => console.log(data))
  }

  render () {
    const { id } = this.props.match.params
    console.log(id)
    const item = this.props.blogs.find(item => item.id == id)
    console.log(item)
    return (
      <div>
        <Editdetails item={item} handleSubmit={this.handleSubmit} />
      </div>
    )
  }
}

const mapStateToProps = state => {
  return {
    blogs: state.blogs
  }
}

const mapDispatchToProps = dispatch => {
  return {
    update: val => dispatch({ type: 'update', payload: val })
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Edit)
