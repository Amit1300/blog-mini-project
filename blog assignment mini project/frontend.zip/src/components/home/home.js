import React, { Component } from 'react'
// import 'bootstrap/dist/css/bootstrap.css';
import { Link, useHistory } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css'
import { withCookies, Cookies } from 'react-cookie'
import './home.css'
import { connect } from 'react-redux'
import Button from '@material-ui/core/Button'
import IconButton from '@material-ui/core/IconButton'
import DeleteIcon from '@material-ui/icons/Delete'
import {
  Navbar,
  Form,
  FormControl,
  Nav,
  NavDropdown,
  Card,
  CardImg
} from 'react-bootstrap'
import './home.css'

class Home extends Component {
  constructor (props) {
    super(props)
    this.state = {
      blog: []
    }
  }

  logout = () => {
    localStorage.clear()
    this.props.history.replace('/Login')
  }

  handledelete = id => {
    let token = localStorage.getItem('token')

    fetch(`http://127.0.0.1:8000/api/blog/${id}/`, {
      method: 'DELETE',
      headers: {
        'Content-type': 'application/json',
        Authorization: `Token ${token}`
      }
    })
      .then(res => {
        console.log(res)
        if(res.status==204){
          this.props.del(id)

        }
     
      })
      .catch(err => console.log(err))
  }

  componentDidMount () {
    let token = localStorage.getItem('token')

    let url = `http://127.0.0.1:8000/api/blog`
    fetch(url, {
      method: 'GET',
      headers: {
        'Content-type': 'multipart/form-data',
        Authorization: `Token ${token}`
      }
    })
      .then(response => response.json())
      .then(data => {
        console.log(data)
        this.props.add(data)
        this.setState({ blog: data })
      })
      .catch(error => console.log(error))
  }
  render () {
    // console.log(this.props.blogs)
    return (
      <div>
        <div>
          <Navbar expand='lg' id="nav">
            <Navbar.Brand style={{color:'white'}}>Blog App</Navbar.Brand>
            <Navbar.Toggle aria-controls='basic-navbar-nav' />
            <Navbar.Collapse id='basic-navbar-nav'>
              <Nav className='mr-auto'>
                <Nav.Link style={{color:'white'}}>
                  <Link style={{color:'white',textDecoration:'none'}} to='/home'>Home</Link>
                </Nav.Link>
                <Nav.Link >
                
                  <Link style={{color:'white',textDecoration:'none'}} to='/createblog'>Create Blog</Link>
                </Nav.Link>
                <Nav.Link style={{color:'white'}}>
                  <Link to='/author' style={{color:'white',textDecoration:'none'}}>Author</Link>
                </Nav.Link >
                <Nav.Link onClick={this.logout} style={{color:'white'}}>Logout</Nav.Link>
              </Nav>
              <Form inline>
                <FormControl
                  type='text'
                  placeholder='Search'
                  className='mr-sm-2'
                />
                <Button variant='outline-success'  style={{color:'white',textDecoration:'none'}}>Search</Button>
              </Form>
            </Navbar.Collapse>
          </Navbar>
        </div>
      {this.state.blog.length!=0 ?
       ( <div className='container-fluid m-3' >
          <div className='row'>
            {this.state.blog.map(item => (
              <div className='col-lg-4 '>
                <Card key={item.id} className='card' style={{ width: '28rem' }} id="card">
                  <Card.Body id='car'>
                    <Card.Title className='primary-text'>
                      {item.title}
                      {item.blog}
                    <h4>{item.Author}</h4>
                    </Card.Title>
                    <Card.Text>{item.content}...</Card.Text>

                    <Button
                      onClick={() => {
                        this.handledelete(item.id)
                      }}
                    >
             
                    </Button>
                    <IconButton aria-label='delete' id="icon">
                      <DeleteIcon
                        onClick={() => {
                          this.handledelete(item.id)
                        }}
                        variant='outlined'
                        color='secondary'
                      />
                    </IconButton>
                    <Button id="but">
                      <Link
                        style={{ textDecoration: 'none' }}
                        to={`/edit/${item.id}`}
                      >
                        Edit
                      </Link>
                    </Button>
                  </Card.Body>
                </Card>
              </div>
            ))}
          </div>
        </div>):<h1>no blog</h1>}
      </div>
    )
  }
}

const mapStateToProps = state => {
  return {
    blogs: state.blogs
  }
}

const mapDispatchToProps = dispatch => {
  return {
    add: val => dispatch({ type: 'DATA', payload: val }),
    del: val => dispatch({ type: 'DEL', payload: val })
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Home)
