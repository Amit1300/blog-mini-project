import './App.css'
import React from 'react'

import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'

import { CookiesProvider } from 'react-cookie'
import Home from './components/home/home'
import Author from './components/Authors/author'
import CreateBlog from './components/Blogs/createblog'
import Login from './components/login/login'
import Signup from './components/signup/signup'
import Edit from './components/edit/edit'
import Starter from './starter/starter'
import SignUp from './components/signup/signup'
import ErrorBoundary from './components/errorboundary'

class App extends React.Component {
  constructor (props) {
    super(props)
  }

  render () {
    return (
      <div className='App'>
        <Router>
          
         
          <Switch>
            <ErrorBoundary>
         
            <Route path='/author' component={Author} />
            <Route path='/edit/:id' component={Edit} />
            <Route exact path='/' component={Starter} />
            <Route path='/home' component={Home} />
            <Route path='/Login' component={Login} />
            <Route path='/signup' component={SignUp} />

            <Route path='/createblog' component={CreateBlog} />
            </ErrorBoundary>
         
          </Switch>
       
        </Router>
      </div>
    )
  }
}

export default App
